//
//  ViewController.swift
//  Annem_SearchApp
//
//  Created by Annem,Venkata Bhavana on 3/1/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var imageName: UILabel!
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    @IBOutlet weak var prevButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    
    var arr = [["actor1","actor2","actor3","actor4","actor5"],["book1","book2","book3","book4","book5"],["animal1","animal2","animal3","animal4","animal5",],["start","404error"]]
    
    var actors = ["actors","actor","hero","tollywood","Allu Arjun","Prabhas","Mahesh Babu","Ramcharan","Vijay","celebrity"]
    
    var books = ["books","book","Hobbit","TWO STATES","HARRY POTTER","THE TWILIGHT SAGA","GONE WITH THE WIND","THINK AND GROW RICH "]
    
    var animals = ["animals","animal", "Lion","Tiger","Rat","Cat","Dog"]
    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        prevButton.isHidden = true
        nextButton.isHidden = true
        searchButton.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
        imageName.text = nil
    }
    

    @IBAction func searchTextField(_ sender: UITextField) {
        searchButton.isEnabled = true
        if(sender.text == ""){
            searchButton.isEnabled = false
            
        }
        else{
            prevButton.isEnabled = false
            nextButton.isEnabled = false
            searchButton.isEnabled = true
            resetButton.isHidden = false
    }
    }
    
        
        
    
    
    var actor = [["Allu Arjun","Prabhas","Mahesh Babu","Ramcharan","Vijay"],["Allu Arjun (born 8 April 1982) is an Indian actor who predominantly works in Telugu films. He is one of the highest paid actors in South India and known for his dancing abilities,Allu is a recipient of several awards, including five Filmfare Awards South and five Nandi Awards. Since 2014, he has been featured in Forbes India's Celebrity 100 list based on his income and popularity.","Uppalapati Venkata Suryanarayana Prabhas Raju (born 23 October 1979), known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in Indian cinema, Prabhas has featured in Forbes India's Celebrity 100 list three times since 2015 based on his income and popularity.He has received seven Filmfare Awards South nominations and is a recipient of the Nandi Award and the SIIMA Award.","Ghattamaneni Mahesh Babu (born 9 August 1975) is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema. He has appeared in more than 25 films, and won several accolades including, eight Nandi Awards, five Filmfare South Awards, four South Indian International Movie Awards, three CineMAA Awards, and one IIFA Utsavam Award. He also owns the production house G. Mahesh Babu Entertainment.","Konidela Ram Charan Teja (born 27 March 1985) is an Indian actor, producer and entrepreneur who works predominantly in Telugu cinema. One of the highest-paid actors in India, he is the recipient of several awards, including three Filmfare Awards and two Nandi Awards. Since 2013, he has been featured in Forbes India's Celebrity 100 list based on his income and popularity.","Joseph Vijay Chandrasekhar (born 22 June 1974), known mononymously as Vijay, is an Indian actor, dancer, playback singer and philanthropist who works predominantly in Tamil cinema and also appeared in other Indian languages films. Vijay is the highest paid actor in South India.He has significant fan following globally and has acted in 65 films as a lead actor. He has won won numerous awards, including eight Vijay Awards by Star India, three Tamil Nadu State Film Awards by Government of Tamil Nadu, and a SIIMA Award. He has been included several times in the Forbes India Celebrity 100 list, based on the earnings of Indian celebrities. Pan-Indian demand for his films, made him a sought-after actor in Hindi cinema."]]
    
    var book = [["TWO STATES","HARRY POTTER","THE TWILIGHT SAGA","GONE WITH THE WIND","THINK AND GROW RICH"],["2 States is a 2014 Indian Hindi-language romantic comedy-drama film based on Chetan Bhagat's 2009 novel 2 States: The Story of My Marriage and written by Abhishek Varman and Bhagat.Directed by Varman in his directorial debut, the film was jointly produced by Karan Johar and Sajid Nadiadwala under their respective banners Dharma Productions and Nadiadwala Grandson Entertainment on a total budget of ₹320 million (US$4.2 million). Featuring Arjun Kapoor and Alia Bhatt in lead roles, 2 States co-stars Amrita Singh, Ronit Roy, Revathi and Shiv Kumar Subramaniam as supporting cast.","Harry Potter is a series of seven fantasy novels written by British author J. K. Rowling. The novels chronicle the lives of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley, all of whom are students at Hogwarts School of Witchcraft and Wizardry. The main story arc concerns Harry's struggle against Lord Voldemort, a dark wizard who intends to become immortal, overthrow the wizard governing body known as the Ministry of Magic and subjugate all wizards and Muggles (non-magical people).","The Twilight Saga is a series of five vampire-themed romance fantasy films from Summit Entertainment based on the four novels published by author Stephenie Meyer. The series has grossed over $3.4 billion worldwide. The first installment, Twilight, was released on November 21, 2008. The second installment, New Moon, followed on November 20, 2009, breaking box office records as the biggest midnight screening and opening day in history, grossing an estimated $72.7 million. The third installment, Eclipse, was released on June 30, 2010, and was the first of the series to be released in IMAX","Gone with the Wind is a 1939 American epic historical romance film adapted from the 1936 novel by Margaret Mitchell. The film was produced by David O. Selznick of Selznick International Pictures and directed by Victor Fleming. Set in the American South against the backdrop of the American Civil War and the Reconstruction era, the film tells the story of Scarlett O'Hara (portrayed by Vivien Leigh), the strong-willed daughter of a Georgia plantation owner, following her romantic pursuit of Ashley Wilkes (Leslie Howard), who is married to his cousin, Melanie Hamilton (Olivia de Havilland), and her subsequent marriage to Rhett Butler (Clark Gable)","Think and Grow Rich is a book written by Napoleon Hill in 1937 and promoted as a personal development and self-improvement book. He claimed to be inspired by a suggestion from business magnate and later-philanthropist Andrew Carnegie.First published during the Great Depression, the book has sold more than 15 million copies"]]
                                                                                                              
    var animal = [["Lion","Tiger","Rat","Cat","Dog"],["The lion (Panthera leo) is a large cat of the genus Panthera native to Africa and India. It has a muscular, deep-chested body, short, rounded head, round ears, and a hairy tuft at the end of its tail. It is sexually dimorphic; adult male lions are larger than females and have a prominent mane. It is a social species, forming groups called prides. A lion's pride consists of a few adult males, related females, and cubs. Groups of female lions usually hunt together, preying mostly on large ungulates. The lion is an apex and keystone predator; although some lions scavenge when opportunities occur and have been known to hunt humans, the species typically does not.","The tiger (Panthera tigris) is the largest living cat species and a member of the genus Panthera. It is most recognisable for its dark vertical stripes on orange fur with a white underside. An apex predator, it primarily preys on ungulates such as deer and wild boar. It is territorial and generally a solitary but social predator, requiring large contiguous areas of habitat, which support its requirements for prey and rearing of its offspring. Tiger cubs stay with their mother for about two years, then become independent and leave their mother's home range to establish their own.","Rats are various medium-sized, long-tailed rodents. Species of rats are found throughout the order Rodentia, but stereotypical rats are found in the genus Rattus. Other rat genera include Neotoma (pack rats), Bandicota (bandicoot rats) and Dipodomys (kangaroo rats).Rats are typically distinguished from mice by their size. Usually the common name of a large muroid rodent will include the word rat,while a smaller muroid's name will include mouse. The common terms rat and mouse are not taxonomically specific. There are 56 known species of rats in the world.","The cat (Felis catus) is a domestic species of a small carnivorous mammal. It is the only domesticated species in the family Felidae and is often referred to as the domestic cat to distinguish it from the wild members of the family. A cat can either be a house cat, a farm cat or a feral cat; the latter ranges freely and avoids human contact. Domestic cats are valued by humans for companionship and their ability to kill rodents. About 60 cat breeds are recognized by various cat registries.","The dog or domestic dog (Canis familiaris or Canis lupus familiaris) is a domesticated descendant of the wolf which is characterized by an upturning tail. The dog is derived from an ancient, extinct wolf, and the modern wolf is the dog's nearest living relative. The dog was the first species to be domesticated, by hunter–gatherers over 15,000 years ago, before the development of agriculture."]]
    
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        prevButton.isHidden = false
        nextButton.isHidden = false
        prevButton.isEnabled = false
        nextButton.isEnabled = false
        resetButton.isEnabled = true
        if(actors.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[0][imag1])
            imageName.text = actor[0][name1]
            topic = 1
            topicInfoText.text = actor[1][text1]
        }
        else if(books.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[1][imag2])
            imageName.text = book[0][name2]
            topic = 2
            topicInfoText.text = book[1][text2]
        }
        else if(animals.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[2][imag3])
            imageName.text = book[0][name3]
            topic = 3
            topicInfoText.text = animal[1][text3]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])
            topicInfoText.text = nil
            imageName.text = nil
            prevButton.isHidden = true
            nextButton.isHidden = true
            resetButton.isEnabled = true
        }
        
        
    }
    
    @IBAction func showPrevImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 -= 1
            name1 -= 1
            text1 -= 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 -= 1
            name2 -= 1
            text2 -= 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 -= 1
            name3 -= 1
            text3 -= 1
            dataUpdate(imgNo: imag3)
        }
        
    }
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 += 1
            name1 += 1
            text1 += 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 += 1
            name2 += 1
            text2 += 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 += 1
            name3 += 1
            text3 += 1
            dataUpdate(imgNo: imag3)
        }
    }
    
    
    @IBAction func resetButton(_ sender: Any) {
        prevButton.isHidden = true
        nextButton.isHidden = true
        topicInfoText.text = nil
        imageName.text = nil
        searchTextField.text = nil
        resetButton.isHidden = true
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        topic = 0
        
        
    }
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if imag1 == arr[0].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][text1]
            }
            else if(imag1 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][text1]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][text1]
            }
        }
        if(topic == 2){
            if imag2 == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                imageName.text = book[0][name2]
                topicInfoText.text = book[1][text2]
            }
            else if(imag2 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                imageName.text = book[0][name2]
                topicInfoText.text = book[1][text2]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                imageName.text = book[0][name2]
                topicInfoText.text = book[1][text2]
                
            }
        }
        if(topic == 3){
            if imag3 == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][text3]
            }
            else if(imag3 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][text3]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][text3]
                
            }
        }
    }
}

